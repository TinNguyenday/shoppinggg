const MyConstants = {
    DB_SERVER: 'webnangcao.nnfl5vi.mongodb.net',
    DB_USER: 'thanhan34502',
    DB_PASS: 'thanhan11082003',
    DB_DATABASE: 'shoppingonline',
    JWT_SECRET: '123456',
    JWT_EXPIRES: '360000000000', // in milliseconds
    EMAIL_USER: 'nguyenvuthanhan1@gmail.com', // gmail service
    EMAIL_PASS: 'fcly pbby rlwh oyov'
  };
  module.exports = MyConstants;